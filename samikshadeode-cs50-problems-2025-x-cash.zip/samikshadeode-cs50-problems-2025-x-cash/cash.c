#include <cs50.h>
#include <stdio.h>

int calculate_coin(int change, int denomination) 
{
    return change / denomination;
}
int new_change(int change, int denomination)
{
    change = change - (denomination * (change / denomination));
    return change;
}

int main(void)

{
    int change;
    do
    {
        change = get_int("Enter the change owed:"); // prompt the user for change
    }
    while (change < 0);

    int quarters = calculate_coin(change, 25); // find the number of quarters
    change = new_change(change, 25);           // calculate remaining change

    int dimes = calculate_coin(change, 10); // find the number of dimes
    change = new_change(change, 10);        // calculate remaining change

    int nickels = calculate_coin(change, 5); // find the number of nickels
    change = new_change(change, 5);          // calculate remaining change

    int pennies = calculate_coin(change, 1); // find the number of pennies

    int total = quarters + dimes + nickels + pennies; // find total number of coins

    printf("%i\n", total);
}
