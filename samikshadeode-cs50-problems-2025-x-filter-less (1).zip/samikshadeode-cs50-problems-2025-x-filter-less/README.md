These are the assignments submitted by me for cs50
