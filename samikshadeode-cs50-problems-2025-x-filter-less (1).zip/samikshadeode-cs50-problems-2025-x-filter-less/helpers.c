#include "helpers.h"
#include<math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
  int average;

  for(int i=0 ; i < height ; i++)
  {
    for(int j=0 ; j< width ; j++)
    {
         average=round((image[i][j].rgbtRed + image[i][j].rgbtGreen + image[i][j].rgbtBlue)/3.0);

        image[i][j].rgbtRed=average;
        image[i][j].rgbtGreen=average;
        image[i][j].rgbtBlue=average;

    }
  }


    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
  int sepiaRed;
  int sepiaGreen;
  int sepiaBlue;
    for(int i=0; i<height; i++)
    {
        for(int j=0 ; j< width ; j++)
        {
           sepiaRed = round(.393 * image[i][j].rgbtRed + .769 * image[i][j].rgbtGreen + .189 * image[i][j].rgbtBlue);
           sepiaGreen=round(.349 * image[i][j].rgbtRed + .686 *image[i][j].rgbtGreen + .168 * image[i][j].rgbtBlue);
           sepiaBlue =round(.272 * image[i][j].rgbtRed + .534 * image[i][j].rgbtGreen + .131 * image[i][j].rgbtBlue);

           if(sepiaRed>255)
           {
            sepiaRed=255;
           }

           if(sepiaGreen>255)
           {
            sepiaGreen=255;
           }

           if(sepiaBlue>255)
           {
            sepiaBlue=255;
           }

           image[i][j].rgbtRed=sepiaRed;
           image[i][j].rgbtGreen=sepiaGreen;
           image[i][j].rgbtBlue=sepiaBlue;


          }
    }


    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
  for(int i=0 ; i < height ; i++)
  {
    for(int j=0 ; j< (width/2) ; j++)
    {
       RGBTRIPLE temp;
       temp=image[i][j];
       image[i][j]=image[i][width-1-j];
       image[i][width-1-j]=temp;
    }
  }

    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
  RGBTRIPLE copy[height][width];
  for(int i=0 ; i< height ; i++)
  {
    for(int j=0 ; j< width ; j++)
    {
      copy[i][j]=image[i][j];
    }
  }

  for(int i=0 ; i<height ; i++)
  {
    for(int j=0 ; j<width ; j++)
    {
      int redtotal=0;
      int greentotal=0;
      int bluetotal=0;
      int count=0;


      for(int k=-1 ; k<=1 ; k++)
      {
        for(int l=-1 ; l<=1 ; l++)
        {
          int ni=i+k;
          int nj=j+l;

          if(ni>=0 && ni<height && nj>=0 && nj<width)
        {
          redtotal=redtotal+copy[ni][nj].rgbtRed;
          greentotal=greentotal+copy[ni][nj].rgbtGreen;
          bluetotal=bluetotal+copy[ni][nj].rgbtBlue;
          count++;

        }

      }
    }

        image[i][j].rgbtRed=round(redtotal / (float)count) ;
        image[i][j].rgbtGreen=round( greentotal / (float)count) ;
        image[i][j].rgbtBlue= round(bluetotal / (float)count) ;

  }
}
}
