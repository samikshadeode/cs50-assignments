#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int count_letters(string text);
int count_words(string text);
int count_sentences(string text);
float calculate_L(int letters, int words);
float calculate_S(int sentences, int words);
int calculate_index(float L, float S);
void displayresult(int index);

int main(void)
{
    string text = get_string(" Text:"); // prompt the user for input

    int letters = count_letters(
        text); // when calling function there is no need to specify types of arguements
    int words = count_words(text);
    int sentences = count_sentences(text);
    float L = calculate_L(letters, words);
    float S = calculate_S(sentences, words);
    int index = calculate_index(L, S);
    displayresult(index);
}

int count_letters(string text) // calculate number of letters
{
    int count = 0;

    int length = strlen(text);

    for (int i = 0; i < length; i++)
    {
        if (isalpha(text[i]))
        {
            count++;
        }
    }
    return count;
}

int count_words(string text) // calculate number of words
{
    int count = 1;

    int length = strlen(text);

    for (int i = 0; i < length; i++)
    {
        if (text[i] == ' ')
        {
            count++;
        }
    }
    return count;
}

int count_sentences(string text) // calculate number of sentences
{
    int count = 0;

    int length = strlen(text);

    for (int i = 0; i < length; i++)
    {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            count++;
        }
    }
    return count;
}
float calculate_L(int letters, int words) // find out number of letters per 100 words in the text
{
    return ((float) letters / words) * 100; // casting
}

float calculate_S(int sentences, int words) // find out number of sentences per 100 words in text
{
    return ((float) sentences / words) * 100;
}

int calculate_index(float L, float S) // compute coleman liau index
{
    return round(0.0588 * L - 0.296 * S - 15.8);
}

void displayresult(int index) // print the grade level
{

    if (index <= 16 && index >= 1)
    {
        printf("Grade %i\n", index);
    }
    else if (index > 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Before Grade 1\n");
    }
}
