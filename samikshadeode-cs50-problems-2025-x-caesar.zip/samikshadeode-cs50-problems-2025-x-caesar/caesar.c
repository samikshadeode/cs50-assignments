#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool only_digit(string s);

char rotate(char c, int key);

int main(int argc, string argv[]) // make sure code is run with one command line arguement

{
    if (argc != 2 || !only_digit(argv[1]))
    {
        printf("Usage: ./caesar key.\n"); // making sure only two arguements
        return 1;
    }

    int key = atoi(argv[1]);

    string plaintext = get_string("Plaintext:"); // getting the normal text

    int length = strlen(plaintext);
    printf("Ciphertext:");

    for (int i = 0; i < length; i++)
    {
        char c = rotate(plaintext[i], key);
        printf("%c", c);
    }
    printf("\n");

    return 0;
}

bool only_digit(string s) // making sure that key is only digits
{
    for (int i = 0, length = strlen(s); i < length; i++)
    {
        if (!isdigit(s[i]))
        {
            return false;
        }
    }
    return true;
}

char rotate(char c, int key) // convert ascii to alphabetical index
{
    if (isalpha(c)) // check if it is alphabet in the first place
    {
        if (isupper(c)) // check if it is upppercase

        {                                      // convert to alphabetical index
            return (c - 'A' + key) % 26 + 'A'; // so A is zero , B is one...
        }
        else if (islower(c))
        {
            return (c - 'a' + key) % 26 + 'a'; // so a is zero b is one
        }
    }

    return c;
}
