#include <cs50.h>
#include <stdio.h>
int main(void)
{
    int n;
    do
    {
        n = get_int("Enter the height of the pyramid:");
    }
    while (n < 1 || n > 8);

    for (int i = 1; i <= n; i++) // for the number of rows
    {
        for (int j = (n - i); j > 0; j--)
        {
            printf(" ");
        }
        for (int k = 1; k <= i; k++)
        {
            printf("#");
        }
        printf("\n");
    }
}
